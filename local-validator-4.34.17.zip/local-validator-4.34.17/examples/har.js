{
  "log" : {
    "version" : "1.2b8",
    "creator" : {
      "name" : "Neustar WPM",
      "version" : "1.0"
    },
    "browser" : {
      "name" : "CHROME",
      "version" : "Latest"
    },
    "location" : "local",
    "pages" : [ {
      "id" : "1",
      "startedDateTime" : "2017-07-28T13:41:27.417+0000",
      "title" : "Launch Web Site",
      "pageTimings" : {
        "onContentLoad" : 12889,
        "onLoad" : 19033,
        "_domLoading" : 2056,
        "_domInteractive" : 12888,
        "_domContentLoadedEventStart" : 12889,
        "_domContentLoadedEventEnd" : 12942,
        "_domComplete" : 19032,
        "_loadEventStart" : 19033,
        "_loadEventEnd" : 19037
      }
    }, {
      "id" : "2",
      "startedDateTime" : "2017-07-28T13:41:46.524+0000",
      "title" : "Choose your country_ Select United States",
      "pageTimings" : {
        "onLoad" : 360
      }
    } ],
    "entries" : [ {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:27.633+0000",
      "time" : 1614,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/international.aspx",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
        }, {
          "name" : "Upgrade-Insecure-Requests",
          "value" : "1"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 301,
        "statusText" : "Moved Permanently",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "path" : "/",
          "expires" : "2017-07-28T13:41:26.633+0000"
        }, {
          "name" : "langprefforca",
          "value" : "-1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:16.633+0000"
        }, {
          "name" : "dtmusersessionid",
          "value" : "eb8f612458864fb1a6abbd27f4e5c734",
          "path" : "/",
          "expires" : "2017-07-28T13:41:26.633+0000"
        }, {
          "name" : "assortmentid",
          "value" : "101",
          "path" : "/",
          "expires" : "2038-01-18T04:59:39.633+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:16.633+0000"
        } ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "private"
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "X-AspNet-Version",
          "value" : "4.0.30319"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Set-Cookie",
          "value" : "dntstatus=0; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "langprefforca=-1; expires=Tue, 28-Jul-2037 13:38:37 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "assortmentid=101; expires=Mon, 18-Jan-2038 05:00:00 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Tue, 28-Jul-2037 13:38:37 GMT; path=/"
        }, {
          "name" : "Content-Length",
          "value" : "0"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:39 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "text/html"
        }, {
          "name" : "Location",
          "value" : "/default.aspx"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 0,
          "mimeType" : "text/html"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 0
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 212,
        "connect" : 77,
        "send" : 1,
        "wait" : 1313,
        "receive" : 11,
        "ssl" : -1
      },
      "serverIPAddress" : "23.79.213.212",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:29.253+0000",
      "time" : 373,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/default.aspx",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:28.253+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; assortmentid=101; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
        }, {
          "name" : "Upgrade-Insecure-Requests",
          "value" : "1"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "langprefforca",
          "value" : "-1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:19.253+0000"
        }, {
          "name" : "dtmusersessionid",
          "value" : "eb8f612458864fb1a6abbd27f4e5c734",
          "path" : "/",
          "expires" : "2017-07-28T13:41:28.253+0000"
        }, {
          "name" : "myeid",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:28.253+0000"
        }, {
          "name" : "samebrowsersession",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:28.253+0000"
        }, {
          "name" : "assortmentid",
          "value" : "101",
          "path" : "/",
          "expires" : "2038-01-18T04:59:41.253+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2038-01-18T04:59:41.253+0000"
        }, {
          "name" : "previoussid",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:28.253+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:19.253+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:19.253+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:19.253+0000"
        } ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "private"
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "X-AspNet-Version",
          "value" : "4.0.30319"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Set-Cookie",
          "value" : "langprefforca=-1; expires=Tue, 28-Jul-2037 13:38:38 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "myeid=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "samebrowsersession=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "assortmentid=101; expires=Mon, 18-Jan-2038 05:00:00 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Mon, 18-Jan-2038 05:00:00 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "previoussid=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Tue, 28-Jul-2037 13:38:38 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Tue, 28-Jul-2037 13:38:38 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Tue, 28-Jul-2037 13:38:38 GMT; path=/"
        }, {
          "name" : "Content-Length",
          "value" : "23554"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:39 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "text/html; charset=utf-8"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 23554,
          "mimeType" : "text/html; charset=utf-8"
        },
        "redirectURL" : "",
        "headersSize" : 20,
        "bodySize" : 23554
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 217,
        "receive" : 156,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:29.492+0000",
      "time" : 5789,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/satelliteLib-ce1777e1bada4dc140449149df16d3e22d735b3b.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"844127c21bbbb9a3dec081a8c344af4f:1500983743\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:43 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "40072"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:45 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 40072,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 40072
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 111,
        "connect" : 77,
        "send" : 0,
        "wait" : 5291,
        "receive" : 310,
        "ssl" : -1
      },
      "serverIPAddress" : "23.1.25.126",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:29.495+0000",
      "time" : 1057,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/Shared/css/ecom_merged.css?v=140",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:28.495+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "text/css,*/*;q=0.1"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "140"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 18 Jul 2017 15:23:38 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:40 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "ntCoent-Length",
          "value" : "371997"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0f92ed4d9ffd21:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:40 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "73808"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "text/css"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 73808,
          "mimeType" : "text/css"
        },
        "redirectURL" : "",
        "headersSize" : 15,
        "bodySize" : 73808
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 79,
        "connect" : 77,
        "send" : 1,
        "wait" : 197,
        "receive" : 703,
        "ssl" : -1
      },
      "serverIPAddress" : "23.79.213.212",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:29.495+0000",
      "time" : 845,
      "request" : {
        "method" : "GET",
        "url" : "http://cloud.typography.com/703986/706620/css/fonts.css",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "text/css,*/*;q=0.1"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "cloud.typography.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 302,
        "statusText" : "Moved Temporarily",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "Cache-Control",
          "value" : "must-revalidate, private"
        }, {
          "name" : "ETag",
          "value" : "\"04f43bca8f2ad2332ed9a2f3107fc7b1:1478350474\""
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 July 2017 13:38:40 GMT"
        }, {
          "name" : "Last-Modified",
          "value" : "Sat, 05 Nov 2016 12:54:59 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "154"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:40 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "text/html"
        }, {
          "name" : "Location",
          "value" : "https://fonts.tiffany.com/35731/5F6A5F37E1DD4D2D5.css"
        }, {
          "name" : "X-HCo-pid",
          "value" : "14"
        } ],
        "content" : {
          "size" : 154,
          "mimeType" : "text/html"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 154
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 429,
        "connect" : 77,
        "send" : 1,
        "wait" : 337,
        "receive" : 1,
        "ssl" : -1
      },
      "serverIPAddress" : "23.218.64.246",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:31.208+0000",
      "time" : 7275,
      "request" : {
        "method" : "GET",
        "url" : "https://fonts.tiffany.com/35731/5F6A5F37E1DD4D2D5.css",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "text/css,*/*;q=0.1"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "fonts.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Transfer-Encoding",
          "value" : "chunked"
        }, {
          "name" : "Server",
          "value" : "Microsoft-IIS/7.5"
        }, {
          "name" : "ETag",
          "value" : "\"0ac60968d37d21:0\""
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "Connection",
          "value" : "Transfer-Encoding"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Sat, 05 Nov 2016 17:54:00 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:48 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "text/css"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 210183,
          "mimeType" : "text/css"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 210183
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 1103,
        "connect" : -1,
        "send" : 1,
        "wait" : 254,
        "receive" : 5917,
        "ssl" : -1
      },
      "serverIPAddress" : "23.203.57.201",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:35.287+0000",
      "time" : 1037,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/scripts/libraries/library.js?v=140",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:34.287+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "140"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Transfer-Encoding",
          "value" : "chunked"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 18 Jul 2017 21:48:22 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:45 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0d75193f0d31:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:45 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 218103,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 218103
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 168,
        "receive" : 869,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:36.330+0000",
      "time" : 112,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/scripts/ecom/home.js?v=140",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:35.330+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "140"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0f0f39dbeefd21:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Wed, 28 Jun 2017 03:28:32 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:46 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "722"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:46 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 722,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 722
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 111,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:36.449+0000",
      "time" : 122,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/images/icons/close.png",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:35.449+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"032c17bc5afce1:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Thu, 12 Sep 2013 14:36:36 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:46 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1379"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:46 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/png"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 1379,
          "mimeType" : "image/png"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 1379
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 1,
        "wait" : 120,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:36.574+0000",
      "time" : 130,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/images/loading.gif",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:35.574+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0c5d1592f3dce1:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 19 Apr 2013 18:54:42 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:47 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1385"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:47 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/gif"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 1385,
          "mimeType" : "image/gif"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 1385
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 129,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:36.707+0000",
      "time" : 140,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/local/en-US/images/logo/logo.png",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:35.707+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0c7ec17e641ce1:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Thu, 25 Apr 2013 18:52:54 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:47 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "2860"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:47 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/png"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 2860,
          "mimeType" : "image/png"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 2860
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 139,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:36.850+0000",
      "time" : 381,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/images/wot/WorldOfTiffany1.jpg",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:35.850+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0632d15946cd01:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Wed, 01 Apr 2015 15:54:06 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:47 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "96799"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:47 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/jpeg"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 96799,
          "mimeType" : "image/jpeg"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 96799
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 124,
        "receive" : 257,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:37.238+0000",
      "time" : 146,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/images/header/magnify-glass-retina.png",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:36.238+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"05a8c642f3dce1:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 19 Apr 2013 18:55:00 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:47 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1370"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:47 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/png"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 1370,
          "mimeType" : "image/png"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 1370
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 145,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.530+0000",
      "time" : 129,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-57eac64364746d28e2001c0d.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"4edb5351b4209c315da71a6b169e0c2f:1500983746\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:46 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "345"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:49 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 345,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 13,
        "bodySize" : 345
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 128,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.534+0000",
      "time" : 398,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-56055c7933633000140000c2.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"9a33bcb718d653e0c6c7881912035acd:1500983742\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:42 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1465"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:49 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 1465,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 13,
        "bodySize" : 1465
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 81,
        "connect" : 76,
        "send" : 0,
        "wait" : 240,
        "receive" : 1,
        "ssl" : -1
      },
      "serverIPAddress" : "23.60.73.189",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.534+0000",
      "time" : 389,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-56783aaf64746d234a002925.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"3bfcf5d943f7aef999267c6962141b34:1500983742\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:42 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "742"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:49 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 742,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 13,
        "bodySize" : 742
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 80,
        "connect" : 76,
        "send" : 0,
        "wait" : 233,
        "receive" : 0,
        "ssl" : -1
      },
      "serverIPAddress" : "23.60.73.189",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.534+0000",
      "time" : 445,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-57e99d7464746d3cd4000ae3.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"69b0fb5a86207c48f03cbf2508dd5aa7:1500983742\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:42 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "957"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:49 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 957,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 957
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 79,
        "connect" : 77,
        "send" : 0,
        "wait" : 288,
        "receive" : 1,
        "ssl" : -1
      },
      "serverIPAddress" : "23.60.73.189",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.534+0000",
      "time" : 954,
      "request" : {
        "method" : "GET",
        "url" : "http://media.richrelevance.com/rrserver/js/1.1/p13n.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "media.richrelevance.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Transfer-Encoding",
          "value" : "chunked"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "Cache-Control",
          "value" : "max-age=3600"
        }, {
          "name" : "ETag",
          "value" : "\"50e89d2d9cd37af654f02e103ee570bc:1473996115\""
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 16 Sep 2016 03:21:55 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 12:39:49 GMT"
        }, {
          "name" : "Age",
          "value" : "3540"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 50450,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 10,
        "bodySize" : 50450
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 293,
        "connect" : 76,
        "send" : 1,
        "wait" : 120,
        "receive" : 464,
        "ssl" : -1
      },
      "serverIPAddress" : "23.218.76.139",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.941+0000",
      "time" : 517,
      "request" : {
        "method" : "GET",
        "url" : "http://bat.bing.com/bat.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "bat.bing.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "MUID",
          "value" : "1CCAB7F79A866A6C1903BD3A9E86695A",
          "path" : "/",
          "domain" : ".bing.com",
          "expires" : "2018-08-22T13:38:39.941+0000"
        }, {
          "name" : "MR",
          "value" : "0",
          "path" : "/",
          "domain" : "bat.bing.com",
          "expires" : "2018-01-24T13:38:39.941+0000"
        }, {
          "name" : "MUIDB",
          "value" : "2C20383AEB8A6A450A1832F7EA666B40",
          "path" : "/",
          "expires" : "2019-07-28T13:38:39.941+0000"
        } ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Microsoft-IIS/10.0"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 21 Jul 2017 16:27:46 GMT"
        }, {
          "name" : "X-MSEdge-Ref",
          "value" : "Ref A: F4DF016165B1417C8A217E4FC3DC4F00 Ref B: ASHEDGE0514 Ref C: 2017-07-28T13:38:49Z"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:48 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "private,max-age=1800"
        }, {
          "name" : "ETag",
          "value" : "\"06d2493e2d31:0\""
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Set-Cookie",
          "value" : "MUID=1CCAB7F79A866A6C1903BD3A9E86695A; domain=.bing.com; expires=Wed, 22-Aug-2018 13:38:49 GMT; path=/;"
        }, {
          "name" : "Set-Cookie",
          "value" : "MR=0; domain=bat.bing.com; expires=Wed, 24-Jan-2018 13:38:49 GMT; path=/;"
        }, {
          "name" : "Set-Cookie",
          "value" : "MUIDB=2C20383AEB8A6A450A1832F7EA666B40; path=/; httponly; expires=Sun, 28-Jul-2019 13:38:49 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "3324"
        }, {
          "name" : "Content-Type",
          "value" : "application/javascript"
        } ],
        "content" : {
          "size" : 3324,
          "mimeType" : "application/javascript"
        },
        "redirectURL" : "",
        "headersSize" : 16,
        "bodySize" : 3324
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 316,
        "connect" : 77,
        "send" : 0,
        "wait" : 117,
        "receive" : 7,
        "ssl" : -1
      },
      "serverIPAddress" : "13.107.21.200",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:38.947+0000",
      "time" : 1257,
      "request" : {
        "method" : "GET",
        "url" : "http://c.go-mpulse.net/boomerang/C9BDV-H6JY3-CRLKK-WDKRW-DRVTQ",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "c.go-mpulse.net"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Transfer-Encoding",
          "value" : "chunked"
        }, {
          "name" : "CF-Cache-Status",
          "value" : "HIT"
        }, {
          "name" : "Cache-Control",
          "value" : "public, max-age=604800"
        }, {
          "name" : "Server",
          "value" : "cloudflare-nginx"
        }, {
          "name" : "CF-RAY",
          "value" : "384fea3377df0785-EWR"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Thu, 03 Aug 2017 13:23:43 GMT"
        }, {
          "name" : "Date",
          "value" : "Thu, 27 Jul 2017 13:23:43 GMT"
        }, {
          "name" : "Age",
          "value" : "87306"
        }, {
          "name" : "Content-Type",
          "value" : "application/javascript;charset=UTF-8"
        } ],
        "content" : {
          "size" : 132158,
          "mimeType" : "application/javascript;charset=UTF-8"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 132158
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 78,
        "connect" : 76,
        "send" : 0,
        "wait" : 87,
        "receive" : 1016,
        "ssl" : -1
      },
      "serverIPAddress" : "104.16.124.228",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.163+0000",
      "time" : 718,
      "request" : {
        "method" : "GET",
        "url" : "https://www.google-analytics.com/analytics.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "www.google-analytics.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Golfe2"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "X-Content-Type-Options",
          "value" : "nosniff"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 06 Jun 2017 00:25:39 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 12:00:29 GMT"
        }, {
          "name" : "Strict-Transport-Security",
          "value" : "max-age=10886400; includeSubDomains; preload"
        }, {
          "name" : "Cache-Control",
          "value" : "public, max-age=7200"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 14:00:29 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "12343"
        }, {
          "name" : "Age",
          "value" : "5901"
        }, {
          "name" : "Content-Type",
          "value" : "text/javascript"
        } ],
        "content" : {
          "size" : 12343,
          "mimeType" : "text/javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 12343
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 78,
        "connect" : -1,
        "send" : 0,
        "wait" : 119,
        "receive" : 521,
        "ssl" : -1
      },
      "serverIPAddress" : "172.217.12.14",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.524+0000",
      "time" : 134,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/fonts/tiffany-icons.ttf?9gdxuq",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:38.524+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "Origin",
          "value" : "http://www.tiffany.com"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/Shared/css/ecom_merged.css?v=140"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "9gdxuq",
          "value" : ""
        } ],
        "headersSize" : 10,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Thu, 09 Mar 2017 19:05:06 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"09d5510899d21:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:50 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "16462"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/octet-stream"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 16462,
          "mimeType" : "application/octet-stream"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 16462
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 117,
        "receive" : 17,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.522+0000",
      "time" : 204,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/Fonts/AvenirNextMedium.woff2",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:38.522+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1"
        }, {
          "name" : "Origin",
          "value" : "http://www.tiffany.com"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/Shared/css/ecom_merged.css?v=140"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 10,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0bc38fffd94d11:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 12 Apr 2016 20:58:00 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:50 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "18760"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/font-woff2"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 18760,
          "mimeType" : "application/font-woff2"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 18760
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 1,
        "wait" : 195,
        "receive" : 8,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.579+0000",
      "time" : 109,
      "request" : {
        "method" : "GET",
        "url" : "http://bat.bing.com/action/0?ti=5437440&Ver=2&mid=e0d439e2-3494-3303-23ce-c5ba27963161&evt=pageLoad&sid=58928d15-1&pi=-1748725250&lg=en-GB&sw=1920&sh=1200&sc=24&tl=Home%20%7C%20Tiffany%20&%20Co.&kw=Tiffany%20and%20Co.,Tiffany,Company,TCO,Gift,Gift%20Card,Gift%20Certificate,Gift%20Registry,Wedding,Wedding%20Registry,Diamonds,Jewelry,Watches,Bridal%20Registry,Home,Home%20Accessories,Accessories,Dinnerware,Drinkware,Flatware,Sterling%20Silver%20Flatware,Table,Vase,Wine&p=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&r=&rn=716343",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "MUID",
          "value" : "1CCAB7F79A866A6C1903BD3A9E86695A",
          "expires" : "2017-07-28T13:41:38.579+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "MUID=1CCAB7F79A866A6C1903BD3A9E86695A; MR=0; MUIDB=2C20383AEB8A6A450A1832F7EA666B40"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "bat.bing.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "ti",
          "value" : "5437440"
        }, {
          "name" : "Ver",
          "value" : "2"
        }, {
          "name" : "mid",
          "value" : "e0d439e2-3494-3303-23ce-c5ba27963161"
        }, {
          "name" : "evt",
          "value" : "pageLoad"
        }, {
          "name" : "sid",
          "value" : "58928d15-1"
        }, {
          "name" : "pi",
          "value" : "-1748725250"
        }, {
          "name" : "lg",
          "value" : "en-GB"
        }, {
          "name" : "sw",
          "value" : "1920"
        }, {
          "name" : "sh",
          "value" : "1200"
        }, {
          "name" : "sc",
          "value" : "24"
        }, {
          "name" : "tl",
          "value" : "Home | Tiffany "
        }, {
          "name" : " Co.",
          "value" : ""
        }, {
          "name" : "kw",
          "value" : "Tiffany and Co.,Tiffany,Company,TCO,Gift,Gift Card,Gift Certificate,Gift Registry,Wedding,Wedding Registry,Diamonds,Jewelry,Watches,Bridal Registry,Home,Home Accessories,Accessories,Dinnerware,Drinkware,Flatware,Sterling Silver Flatware,Table,Vase,Wine"
        }, {
          "name" : "p",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "r",
          "value" : ""
        }, {
          "name" : "rn",
          "value" : "716343"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 204,
        "statusText" : "No Content",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "no-cache, must-revalidate"
        }, {
          "name" : "Server",
          "value" : "Microsoft-IIS/10.0"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "Expires",
          "value" : "Fri, 01 Jan 1990 00:00:00 GMT"
        }, {
          "name" : "X-MSEdge-Ref",
          "value" : "Ref A: C8FEF5C350CB41B980297CBAF358033D Ref B: ASHEDGE0514 Ref C: 2017-07-28T13:38:50Z"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:49 GMT"
        } ],
        "content" : {
          "size" : 0
        },
        "redirectURL" : "",
        "headersSize" : 8,
        "bodySize" : 0
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 109,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.765+0000",
      "time" : 536,
      "request" : {
        "method" : "GET",
        "url" : "http://ds.serving-sys.com/SemiCachedScripts/ebOneTag.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Intervention",
          "value" : "<https://www.chromestatus.com/feature/5718547946799104>; level=\"warning\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "ds.serving-sys.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Microsoft-IIS/8.5"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Sun, 16 Jul 2017 10:30:29 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "max-age=144"
        }, {
          "name" : "ETag",
          "value" : "W/\"8cc498c1efed21:0\""
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Content-Length",
          "value" : "11819"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/javascript"
        }, {
          "name" : "X-Powered-By",
          "value" : "ARR/2.5"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 11819,
          "mimeType" : "application/javascript"
        },
        "redirectURL" : "",
        "headersSize" : 15,
        "bodySize" : 11819
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 129,
        "connect" : 76,
        "send" : 0,
        "wait" : 178,
        "receive" : 153,
        "ssl" : -1
      },
      "serverIPAddress" : "65.153.18.80",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.890+0000",
      "time" : 123,
      "request" : {
        "method" : "GET",
        "url" : "https://www.google-analytics.com/plugins/ua/ec.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "www.google-analytics.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "sffe"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "X-Content-Type-Options",
          "value" : "nosniff"
        }, {
          "name" : "Last-Modified",
          "value" : "Thu, 21 Apr 2016 03:17:22 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:14:49 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public, max-age=3600"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 14:14:49 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1296"
        }, {
          "name" : "X-XSS-Protection",
          "value" : "1; mode=block"
        }, {
          "name" : "Age",
          "value" : "1441"
        }, {
          "name" : "Content-Type",
          "value" : "text/javascript"
        } ],
        "content" : {
          "size" : 1296,
          "mimeType" : "text/javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 1296
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 122,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:39.912+0000",
      "time" : 444,
      "request" : {
        "method" : "GET",
        "url" : "https://www.google-analytics.com/plugins/ua/linkid.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "www.google-analytics.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "sffe"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "X-Content-Type-Options",
          "value" : "nosniff"
        }, {
          "name" : "Last-Modified",
          "value" : "Thu, 21 Apr 2016 03:17:22 GMT"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:04:45 GMT"
        }, {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public, max-age=3600"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 14:04:45 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "856"
        }, {
          "name" : "X-XSS-Protection",
          "value" : "1; mode=block"
        }, {
          "name" : "Age",
          "value" : "2045"
        }, {
          "name" : "Content-Type",
          "value" : "text/javascript"
        } ],
        "content" : {
          "size" : 856,
          "mimeType" : "text/javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 856
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 81,
        "connect" : -1,
        "send" : 0,
        "wait" : 119,
        "receive" : 244,
        "ssl" : -1
      },
      "serverIPAddress" : "172.217.12.14",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.229+0000",
      "time" : 112,
      "request" : {
        "method" : "GET",
        "url" : "http://c.go-mpulse.net/boomerang/config.js?key=C9BDV-H6JY3-CRLKK-WDKRW-DRVTQ&d=www.tiffany.com&t=5004164&v=1.413.1477614597&if=&sl=0&si=xnbejnrqdhl-NaN&plugins=ConfigOverride,PageParams,AutoXHR,SPA,Angular,Backbone,Ember,History,RT,CrossDomain,BW,NavigationTiming,ResourceTiming,Memory,CACHE_RELOAD,Errors,TPAnalytics,LOGN",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "c.go-mpulse.net"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "key",
          "value" : "C9BDV-H6JY3-CRLKK-WDKRW-DRVTQ"
        }, {
          "name" : "d",
          "value" : "www.tiffany.com"
        }, {
          "name" : "t",
          "value" : "5004164"
        }, {
          "name" : "v",
          "value" : "1.413.1477614597"
        }, {
          "name" : "if",
          "value" : ""
        }, {
          "name" : "sl",
          "value" : "0"
        }, {
          "name" : "si",
          "value" : "xnbejnrqdhl-NaN"
        }, {
          "name" : "plugins",
          "value" : "ConfigOverride,PageParams,AutoXHR,SPA,Angular,Backbone,Ember,History,RT,CrossDomain,BW,NavigationTiming,ResourceTiming,Memory,CACHE_RELOAD,Errors,TPAnalytics,LOGN"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Transfer-Encoding",
          "value" : "chunked"
        }, {
          "name" : "Cache-Control",
          "value" : "private, max-age=300, stale-while-revalidate=60, stale-if-error=120"
        }, {
          "name" : "Server",
          "value" : "cloudflare-nginx"
        }, {
          "name" : "CF-RAY",
          "value" : "38583dbae3a30ec1-EWR"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "application/javascript; charset=utf-8"
        } ],
        "content" : {
          "size" : 714,
          "mimeType" : "application/javascript; charset=utf-8"
        },
        "redirectURL" : "",
        "headersSize" : 9,
        "bodySize" : 714
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 112,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.310+0000",
      "time" : 377,
      "request" : {
        "method" : "GET",
        "url" : "http://bs.serving-sys.com/Serving?cn=ot&onetagid=1000&dispType=js&sync=0&sessionid=4390967902787272315&pageurl=$$http%3A//www.tiffany.com/default.aspx$$&ns=0&rnd=7222522162764597",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "bs.serving-sys.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "cn",
          "value" : "ot"
        }, {
          "name" : "onetagid",
          "value" : "1000"
        }, {
          "name" : "dispType",
          "value" : "js"
        }, {
          "name" : "sync",
          "value" : "0"
        }, {
          "name" : "sessionid",
          "value" : "4390967902787272315"
        }, {
          "name" : "pageurl",
          "value" : "$$http://www.tiffany.com/default.aspx$$"
        }, {
          "name" : "ns",
          "value" : "0"
        }, {
          "name" : "rnd",
          "value" : "7222522162764597"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "OT_1000",
          "value" : "1",
          "expires" : "2017-07-28T13:41:39.310+0000"
        }, {
          "name" : "OT2",
          "value" : "0000fE1gd1",
          "path" : "/",
          "domain" : ".serving-sys.com",
          "expires" : "2017-10-26T09:37:52.310+0000"
        }, {
          "name" : "eyeblaster",
          "value" : "",
          "path" : "/",
          "domain" : ".serving-sys.com",
          "expires" : "2017-07-28T13:41:40.310+0000"
        }, {
          "name" : "u2",
          "value" : "9d083df4-40e9-4220-87cf-dfbfc226d7eb4fv070",
          "path" : "/",
          "domain" : ".serving-sys.com",
          "expires" : "2017-10-26T09:37:52.310+0000"
        } ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Microsoft-IIS/7.5"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "P3P",
          "value" : "CP=\"NOI DEVa OUR BUS UNI\""
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Set-Cookie",
          "value" : "OT_1000=1"
        }, {
          "name" : "Set-Cookie",
          "value" : "OT2=0000fE1gd1; expires=Thu, 26-Oct-2017 09:38:00 GMT; domain=.serving-sys.com; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "eyeblaster=; expires=Mon, 01-Jan-2000 00:00:00 GMT; domain=.serving-sys.com; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "u2=9d083df4-40e9-4220-87cf-dfbfc226d7eb4fv070; expires=Thu, 26-Oct-2017 09:38:00 GMT; domain=.serving-sys.com; path=/"
        }, {
          "name" : "Expires",
          "value" : "Sun, 05-Jun-2005 22:00:00 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "243"
        }, {
          "name" : "Content-Type",
          "value" : "text/html; charset=UTF-8"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 243,
          "mimeType" : "text/html; charset=UTF-8"
        },
        "redirectURL" : "",
        "headersSize" : 16,
        "bodySize" : 243
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 78,
        "connect" : 75,
        "send" : 1,
        "wait" : 222,
        "receive" : 1,
        "ssl" : -1
      },
      "serverIPAddress" : "12.129.210.52",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.314+0000",
      "time" : 185,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-56310df264746d6aa1002f1d.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"0b1d3cf1820dcea26e443dbb8c527515:1500983742\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:42 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "536"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 536,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 14,
        "bodySize" : 536
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 185,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.316+0000",
      "time" : 416,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/s-code-contents-7a8fa131fbb9285ec02578bb5ba3cfc97cc963c3.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"f902a23f1b2c5c805b847597cad2c757:1500983741\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:41 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "21020"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 21020,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 13,
        "bodySize" : 21020
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 186,
        "receive" : 230,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.317+0000",
      "time" : 182,
      "request" : {
        "method" : "GET",
        "url" : "http://assets.adobedtm.com/96cc2b959a063996725d32f4ccd6e658f0fa8a39/scripts/satellite-57a4792264746d2e3200111d.js",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "assets.adobedtm.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Server",
          "value" : "Apache"
        }, {
          "name" : "ETag",
          "value" : "\"a04cb2a47ded4f3aaadde4b759a2eca2:1500983742\""
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Timing-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Last-Modified",
          "value" : "Tue, 25 Jul 2017 11:55:42 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "1600"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-javascript"
        } ],
        "content" : {
          "size" : 1600,
          "mimeType" : "application/x-javascript"
        },
        "redirectURL" : "",
        "headersSize" : 13,
        "bodySize" : 1600
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 182,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.338+0000",
      "time" : 178,
      "request" : {
        "method" : "POST",
        "url" : "http://www.tiffany.com/Default.aspx/GetBannerText",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:39.338+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1; _uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300"
        }, {
          "name" : "Origin",
          "value" : "http://www.tiffany.com"
        }, {
          "name" : "Accept",
          "value" : "application/json, text/javascript, */*; q=0.01"
        }, {
          "name" : "X-Requested-With",
          "value" : "XMLHttpRequest"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        }, {
          "name" : "Content-Length",
          "value" : "56"
        }, {
          "name" : "Content-Type",
          "value" : "application/json; charset=UTF-8"
        } ],
        "queryString" : [ ],
        "postData" : {
          "mimeType" : "application/json; charset=UTF-8",
          "params" : [ ],
          "text" : "{\"callingPageType\":\"HomePage\",\"PageURL\":\"/default.aspx\"}"
        },
        "headersSize" : 13,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "langprefforca",
          "value" : "-1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:41.338+0000"
        }, {
          "name" : "dtmusersessionid",
          "value" : "eb8f612458864fb1a6abbd27f4e5c734",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "myeid",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "samebrowsersession",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "assortmentid",
          "value" : "101",
          "path" : "/",
          "expires" : "2038-01-18T04:59:52.338+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2038-01-18T04:59:52.338+0000"
        }, {
          "name" : "previoussid",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "hascookies1",
          "value" : "1",
          "path" : "/",
          "expires" : "2037-07-28T13:38:41.338+0000"
        }, {
          "name" : "bannercookieinfo",
          "value" : "{\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":null,\"UrlVisit\":null}",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "bannercookieinfo",
          "value" : "{\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":\"1\",\"UrlVisit\":null}",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "bannercookieinfo",
          "value" : "{\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":\"1\",\"UrlVisit\":\"/default.aspx\"}",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "taxzpcd",
          "value" : "",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.338+0000"
        }, {
          "name" : "IsFreshBrowserSession",
          "value" : "1",
          "path" : "/",
          "expires" : "2017-07-28T14:08:41.338+0000"
        } ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "private, max-age=0"
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Set-Cookie",
          "value" : "langprefforca=-1; expires=Tue, 28-Jul-2037 13:38:49 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "myeid=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "samebrowsersession=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "assortmentid=101; expires=Mon, 18-Jan-2038 05:00:00 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Mon, 18-Jan-2038 05:00:00 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "previoussid=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "hascookies1=1; expires=Tue, 28-Jul-2037 13:38:49 GMT; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "bannercookieinfo={\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":null,\"UrlVisit\":null}; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "bannercookieinfo={\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":\"1\",\"UrlVisit\":null}; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "bannercookieinfo={\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":\"1\",\"UrlVisit\":\"/default.aspx\"}; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "taxzpcd=; path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "IsFreshBrowserSession=1; expires=Fri, 28-Jul-2017 14:08:49 GMT; path=/"
        }, {
          "name" : "Content-Length",
          "value" : "287"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "application/json; charset=utf-8"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 287,
          "mimeType" : "application/json; charset=utf-8"
        },
        "redirectURL" : "",
        "headersSize" : 22,
        "bodySize" : 287
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 175,
        "receive" : 3,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.358+0000",
      "time" : 160,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/shared/fonts/icon-svgs/directional_down.svg",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:39.358+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1; _uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/Shared/css/ecom_merged.css?v=140"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Accept-Ranges",
          "value" : "bytes"
        }, {
          "name" : "Cache-Control",
          "value" : "public,max-age=604800"
        }, {
          "name" : "ETag",
          "value" : "\"0281ebb38f7d11:0\""
        }, {
          "name" : "Content-Security-Policy",
          "value" : "frame-ancestors 'self'"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Mon, 15 Aug 2016 21:05:20 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 04 Aug 2017 13:38:50 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "199"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/svg+xml"
        }, {
          "name" : "X-Powered-By",
          "value" : "ASP.NET"
        } ],
        "content" : {
          "size" : 199,
          "mimeType" : "image/svg+xml"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 199
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 160,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.478+0000",
      "time" : 130,
      "request" : {
        "method" : "GET",
        "url" : "https://www.google-analytics.com/r/collect?v=1&_v=j56&a=1135201221&t=pageView&cu=USD&_s=1&dl=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&ul=en-gb&de=UTF-8&dt=Home%20%7C%20Tiffany%20%26%20Co.&sd=24-bit&sr=1920x1200&vp=1152x983&je=0&fl=25.0%20r0&_u=aGDACcIpJ~&jid=1091368762&gjid=1392027974&cid=231298761.1501249300&tid=UA-8281472-106&_gid=1874622682.1501249300&_r=1&z=1726530087",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "www.google-analytics.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "1"
        }, {
          "name" : "_v",
          "value" : "j56"
        }, {
          "name" : "a",
          "value" : "1135201221"
        }, {
          "name" : "t",
          "value" : "pageView"
        }, {
          "name" : "cu",
          "value" : "USD"
        }, {
          "name" : "_s",
          "value" : "1"
        }, {
          "name" : "dl",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "ul",
          "value" : "en-gb"
        }, {
          "name" : "de",
          "value" : "UTF-8"
        }, {
          "name" : "dt",
          "value" : "Home | Tiffany "
        }, {
          "name" : " Co.",
          "value" : ""
        }, {
          "name" : "sd",
          "value" : "24-bit"
        }, {
          "name" : "sr",
          "value" : "1920x1200"
        }, {
          "name" : "vp",
          "value" : "1152x983"
        }, {
          "name" : "je",
          "value" : "0"
        }, {
          "name" : "fl",
          "value" : "25.0 r0"
        }, {
          "name" : "_u",
          "value" : "aGDACcIpJ~"
        }, {
          "name" : "jid",
          "value" : "1091368762"
        }, {
          "name" : "gjid",
          "value" : "1392027974"
        }, {
          "name" : "cid",
          "value" : "231298761.1501249300"
        }, {
          "name" : "tid",
          "value" : "UA-8281472-106"
        }, {
          "name" : "_gid",
          "value" : "1874622682.1501249300"
        }, {
          "name" : "_r",
          "value" : "1"
        }, {
          "name" : "z",
          "value" : "1726530087"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 302,
        "statusText" : "Found",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, must-revalidate"
        }, {
          "name" : "Server",
          "value" : "Golfe2"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "Expires",
          "value" : "Fri, 01 Jan 1990 00:00:00 GMT"
        }, {
          "name" : "Last-Modified",
          "value" : "Sun, 17 May 1998 03:00:00 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "420"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Location",
          "value" : "https://stats.g.doubleclick.net/r/collect?v=1&aip=1&t=dc&_r=3&tid=UA-8281472-106&cid=231298761.1501249300&jid=1091368762&_gid=1874622682.1501249300&gjid=1392027974&_v=j56&z=1726530087"
        }, {
          "name" : "Content-Type",
          "value" : "text/html; charset=UTF-8"
        } ],
        "content" : {
          "size" : 420,
          "mimeType" : "text/html; charset=UTF-8"
        },
        "redirectURL" : "",
        "headersSize" : 11,
        "bodySize" : 420
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 129,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.478+0000",
      "time" : 130,
      "request" : {
        "method" : "GET",
        "url" : "https://www.google-analytics.com/r/collect?v=1&_v=j56&a=1135201221&t=pageView&cu=USD&_s=1&dl=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&ul=en-gb&de=UTF-8&dt=Home%20%7C%20Tiffany%20%26%20Co.&sd=24-bit&sr=1920x1200&vp=1152x983&je=0&fl=25.0%20r0&_u=aGDACcIpJ~&jid=989240146&gjid=465332099&cid=231298761.1501249300&tid=UA-8281472-1&_gid=1874622682.1501249300&_r=1&z=1241543532",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "www.google-analytics.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "1"
        }, {
          "name" : "_v",
          "value" : "j56"
        }, {
          "name" : "a",
          "value" : "1135201221"
        }, {
          "name" : "t",
          "value" : "pageView"
        }, {
          "name" : "cu",
          "value" : "USD"
        }, {
          "name" : "_s",
          "value" : "1"
        }, {
          "name" : "dl",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "ul",
          "value" : "en-gb"
        }, {
          "name" : "de",
          "value" : "UTF-8"
        }, {
          "name" : "dt",
          "value" : "Home | Tiffany "
        }, {
          "name" : " Co.",
          "value" : ""
        }, {
          "name" : "sd",
          "value" : "24-bit"
        }, {
          "name" : "sr",
          "value" : "1920x1200"
        }, {
          "name" : "vp",
          "value" : "1152x983"
        }, {
          "name" : "je",
          "value" : "0"
        }, {
          "name" : "fl",
          "value" : "25.0 r0"
        }, {
          "name" : "_u",
          "value" : "aGDACcIpJ~"
        }, {
          "name" : "jid",
          "value" : "989240146"
        }, {
          "name" : "gjid",
          "value" : "465332099"
        }, {
          "name" : "cid",
          "value" : "231298761.1501249300"
        }, {
          "name" : "tid",
          "value" : "UA-8281472-1"
        }, {
          "name" : "_gid",
          "value" : "1874622682.1501249300"
        }, {
          "name" : "_r",
          "value" : "1"
        }, {
          "name" : "z",
          "value" : "1241543532"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 302,
        "statusText" : "Found",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, must-revalidate"
        }, {
          "name" : "Server",
          "value" : "Golfe2"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "Expires",
          "value" : "Fri, 01 Jan 1990 00:00:00 GMT"
        }, {
          "name" : "Last-Modified",
          "value" : "Sun, 17 May 1998 03:00:00 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "416"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:50 GMT"
        }, {
          "name" : "Location",
          "value" : "https://stats.g.doubleclick.net/r/collect?v=1&aip=1&t=dc&_r=3&tid=UA-8281472-1&cid=231298761.1501249300&jid=989240146&_gid=1874622682.1501249300&gjid=465332099&_v=j56&z=1241543532"
        }, {
          "name" : "Content-Type",
          "value" : "text/html; charset=UTF-8"
        } ],
        "content" : {
          "size" : 416,
          "mimeType" : "text/html; charset=UTF-8"
        },
        "redirectURL" : "",
        "headersSize" : 11,
        "bodySize" : 416
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 130,
        "receive" : 0,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.896+0000",
      "time" : 5561,
      "request" : {
        "method" : "GET",
        "url" : "https://stats.g.doubleclick.net/r/collect?v=1&aip=1&t=dc&_r=3&tid=UA-8281472-106&cid=231298761.1501249300&jid=1091368762&_gid=1874622682.1501249300&gjid=1392027974&_v=j56&z=1726530087",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "stats.g.doubleclick.net"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "1"
        }, {
          "name" : "aip",
          "value" : "1"
        }, {
          "name" : "t",
          "value" : "dc"
        }, {
          "name" : "_r",
          "value" : "3"
        }, {
          "name" : "tid",
          "value" : "UA-8281472-106"
        }, {
          "name" : "cid",
          "value" : "231298761.1501249300"
        }, {
          "name" : "jid",
          "value" : "1091368762"
        }, {
          "name" : "_gid",
          "value" : "1874622682.1501249300"
        }, {
          "name" : "gjid",
          "value" : "1392027974"
        }, {
          "name" : "_v",
          "value" : "j56"
        }, {
          "name" : "z",
          "value" : "1726530087"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Strict-Transport-Security",
          "value" : "max-age=10886400; includeSubDomains; preload"
        }, {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, must-revalidate"
        }, {
          "name" : "Server",
          "value" : "Golfe2"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "X-Content-Type-Options",
          "value" : "nosniff"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "Expires",
          "value" : "Fri, 01 Jan 1990 00:00:00 GMT"
        }, {
          "name" : "Last-Modified",
          "value" : "Sun, 17 May 1998 03:00:00 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "35"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:56 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "image/gif"
        } ],
        "content" : {
          "size" : 35,
          "mimeType" : "image/gif"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 35
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 5084,
        "connect" : -1,
        "send" : 0,
        "wait" : 114,
        "receive" : 363,
        "ssl" : -1
      },
      "serverIPAddress" : "64.233.191.156",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.896+0000",
      "time" : 5491,
      "request" : {
        "method" : "GET",
        "url" : "https://stats.g.doubleclick.net/r/collect?v=1&aip=1&t=dc&_r=3&tid=UA-8281472-1&cid=231298761.1501249300&jid=989240146&_gid=1874622682.1501249300&gjid=465332099&_v=j56&z=1241543532",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "Connection",
          "value" : "keep-alive"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Host",
          "value" : "stats.g.doubleclick.net"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate, br"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "1"
        }, {
          "name" : "aip",
          "value" : "1"
        }, {
          "name" : "t",
          "value" : "dc"
        }, {
          "name" : "_r",
          "value" : "3"
        }, {
          "name" : "tid",
          "value" : "UA-8281472-1"
        }, {
          "name" : "cid",
          "value" : "231298761.1501249300"
        }, {
          "name" : "jid",
          "value" : "989240146"
        }, {
          "name" : "_gid",
          "value" : "1874622682.1501249300"
        }, {
          "name" : "gjid",
          "value" : "465332099"
        }, {
          "name" : "_v",
          "value" : "j56"
        }, {
          "name" : "z",
          "value" : "1241543532"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Strict-Transport-Security",
          "value" : "max-age=10886400; includeSubDomains; preload"
        }, {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, must-revalidate"
        }, {
          "name" : "Server",
          "value" : "Golfe2"
        }, {
          "name" : "Alt-Svc",
          "value" : "quic=\":443\"; ma=2592000; v=\"39,38,37,36,35\""
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "X-Content-Type-Options",
          "value" : "nosniff"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "Expires",
          "value" : "Fri, 01 Jan 1990 00:00:00 GMT"
        }, {
          "name" : "Last-Modified",
          "value" : "Sun, 17 May 1998 03:00:00 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "35"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:56 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "image/gif"
        } ],
        "content" : {
          "size" : 35,
          "mimeType" : "image/gif"
        },
        "redirectURL" : "",
        "headersSize" : 12,
        "bodySize" : 35
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 5085,
        "connect" : -1,
        "send" : 0,
        "wait" : 95,
        "receive" : 311,
        "ssl" : -1
      },
      "serverIPAddress" : "173.194.68.155",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:40.978+0000",
      "time" : 620,
      "request" : {
        "method" : "GET",
        "url" : "http://recs.richrelevance.com/rrserver/p13n_generated.js?a=9fcc91a121441cb2&ts=1501249300758&v=1.1.2.20160904&pt=%7Chome_page&s=eb8f612458864fb1a6abbd27f4e5c734&channelId=1f88d8a9478dda98&cts=http%3A%2F%2Fwww.tiffany.com&flv=25.0.0&l=1",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "recs.richrelevance.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "a",
          "value" : "9fcc91a121441cb2"
        }, {
          "name" : "ts",
          "value" : "1501249300758"
        }, {
          "name" : "v",
          "value" : "1.1.2.20160904"
        }, {
          "name" : "pt",
          "value" : "|home_page"
        }, {
          "name" : "s",
          "value" : "eb8f612458864fb1a6abbd27f4e5c734"
        }, {
          "name" : "channelId",
          "value" : "1f88d8a9478dda98"
        }, {
          "name" : "cts",
          "value" : "http://www.tiffany.com"
        }, {
          "name" : "flv",
          "value" : "25.0.0"
        }, {
          "name" : "l",
          "value" : "1"
        } ],
        "headersSize" : 8,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "m",
          "value" : "1",
          "path" : "/",
          "expires" : "2017-07-28T13:41:39.978+0000"
        }, {
          "name" : "n",
          "value" : "1",
          "path" : "/",
          "expires" : "2018-07-28T13:38:43.978+0000"
        }, {
          "name" : "mvtid",
          "value" : "1289-1-1",
          "path" : "/",
          "domain" : "richrelevance.com",
          "expires" : "2018-07-28T13:38:43.978+0000"
        }, {
          "name" : "s",
          "value" : "b25020818.25020818",
          "path" : "/",
          "expires" : "2017-07-28T14:08:43.978+0000"
        }, {
          "name" : "mvtdebug",
          "value" : "1289-1501249131969-1-28325",
          "path" : "/",
          "domain" : "richrelevance.com",
          "expires" : "2018-07-28T13:38:43.978+0000"
        }, {
          "name" : "uc",
          "value" : "11833332-6901-4fc5-ad42-c0576258c9ec",
          "path" : "/",
          "expires" : "2018-07-28T13:38:43.978+0000"
        } ],
        "headers" : [ {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Access-Control-Allow-Methods",
          "value" : "GET, POST, OPTIONS"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Content-Encoding",
          "value" : "gzip"
        }, {
          "name" : "Vary",
          "value" : "Accept-Encoding"
        }, {
          "name" : "Set-Cookie",
          "value" : "m=1;Path=/"
        }, {
          "name" : "Set-Cookie",
          "value" : "n=1;Path=/;Expires=Sat, 28-Jul-2018 13:38:51 GMT"
        }, {
          "name" : "Set-Cookie",
          "value" : "mvtid=1289-1-1;Path=/;Domain=richrelevance.com;Expires=Sat, 28-Jul-2018 13:38:51 GMT"
        }, {
          "name" : "Set-Cookie",
          "value" : "s=b25020818.25020818;Path=/;Expires=Fri, 28-Jul-2017 14:08:51 GMT"
        }, {
          "name" : "Set-Cookie",
          "value" : "mvtdebug=1289-1501249131969-1-28325;Path=/;Domain=richrelevance.com;Expires=Sat, 28-Jul-2018 13:38:51 GMT"
        }, {
          "name" : "Set-Cookie",
          "value" : "uc=11833332-6901-4fc5-ad42-c0576258c9ec;Path=/;Expires=Sat, 28-Jul-2018 13:38:51 GMT"
        }, {
          "name" : "Expires",
          "value" : "Thu, 01 Jan 1970 00:00:00 GMT"
        }, {
          "name" : "P3p",
          "value" : "policyref=\"http://recs.richrelevance.com/w3c/p3p.xml\", CP=\"NOI DSP COR NID CUR OUR NOR\""
        }, {
          "name" : "Content-Length",
          "value" : "427"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:51 GMT"
        }, {
          "name" : "Content-Type",
          "value" : "text/javascript;charset=utf-8"
        } ],
        "content" : {
          "size" : 427,
          "mimeType" : "text/javascript;charset=utf-8"
        },
        "redirectURL" : "",
        "headersSize" : 16,
        "bodySize" : 427
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 404,
        "connect" : 78,
        "send" : 0,
        "wait" : 136,
        "receive" : 2,
        "ssl" : -1
      },
      "serverIPAddress" : "204.93.199.121",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:41.000+0000",
      "time" : 3995,
      "request" : {
        "method" : "GET",
        "url" : "http://stats.tiffany.com/b/ss/tiffanyrus,tiffanyglobal/1/JS-2.1.0-D7QN/s42144444641557?AQB=1&ndh=1&pf=1&t=28%2F6%2F2017%2014%3A41%3A40%205%20-60&D=D%3D&fid=635E58A259D7A835-33DAEBDE5968F475&ce=utf-8&pageName=Tiffany%20%26%20Co.%20%7C%20Home&g=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&cc=USD&ch=home&server=www.tiffany.com&c1=Home&h1=Home&h2=us%2CHome&v11=9%3A41%20AM%7CFriday&c12=9%3A41%20AM%7CFriday&c21=desktop&c23=D%3Dg&c24=D%3Dv64&c25=en&c26=Home%20%7C%20Tiffany%20%26%20Co.&c37=D%3Dv49&v41=D%3Dh2&c44=D%3Dv52&v44=D%3Dcc&v52=not%20logged%20in&v64=us%3ATiffany%20%26%20Co.%20%7C%20Home&v65=www.tiffany.com%2Fdefault.aspx&v67=www.tiffany.com&v68=%2B1&c70=high%20resolution&c71=http%3Astats.tiffany.com&c72=epd28&c73=1%3A1%3A1%3A1%3A1%3A1%3A1%3A1%7C2017.07.21%7C2017.07.25%7C2.1.0%7C&c75=D%3Dv65&v83=2017-07-28&s=1920x1200&c=24&j=1.6&v=N&k=Y&bw=1152&bh=983&AQE=1",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "_uetsid",
          "value" : "_uet58928d15",
          "expires" : "2017-07-28T13:41:40.000+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "_uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "stats.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "AQB",
          "value" : "1"
        }, {
          "name" : "ndh",
          "value" : "1"
        }, {
          "name" : "pf",
          "value" : "1"
        }, {
          "name" : "t",
          "value" : "28/6/2017 14:41:40 5 -60"
        }, {
          "name" : "D",
          "value" : "D"
        }, {
          "name" : "fid",
          "value" : "635E58A259D7A835-33DAEBDE5968F475"
        }, {
          "name" : "ce",
          "value" : "utf-8"
        }, {
          "name" : "pageName",
          "value" : "Tiffany "
        }, {
          "name" : " Co. | Home",
          "value" : ""
        }, {
          "name" : "g",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "cc",
          "value" : "USD"
        }, {
          "name" : "ch",
          "value" : "home"
        }, {
          "name" : "server",
          "value" : "www.tiffany.com"
        }, {
          "name" : "c1",
          "value" : "Home"
        }, {
          "name" : "h1",
          "value" : "Home"
        }, {
          "name" : "h2",
          "value" : "us,Home"
        }, {
          "name" : "v11",
          "value" : "9:41 AM|Friday"
        }, {
          "name" : "c12",
          "value" : "9:41 AM|Friday"
        }, {
          "name" : "c21",
          "value" : "desktop"
        }, {
          "name" : "c25",
          "value" : "en"
        }, {
          "name" : "c26",
          "value" : "Home | Tiffany "
        }, {
          "name" : " Co.",
          "value" : ""
        }, {
          "name" : "v52",
          "value" : "not logged in"
        }, {
          "name" : "v64",
          "value" : "us:Tiffany "
        }, {
          "name" : " Co. | Home",
          "value" : ""
        }, {
          "name" : "v65",
          "value" : "www.tiffany.com/default.aspx"
        }, {
          "name" : "v67",
          "value" : "www.tiffany.com"
        }, {
          "name" : "v68",
          "value" : "+1"
        }, {
          "name" : "c70",
          "value" : "high resolution"
        }, {
          "name" : "c71",
          "value" : "http:stats.tiffany.com"
        }, {
          "name" : "c72",
          "value" : "epd28"
        }, {
          "name" : "c73",
          "value" : "1:1:1:1:1:1:1:1|2017.07.21|2017.07.25|2.1.0|"
        }, {
          "name" : "v83",
          "value" : "2017-07-28"
        }, {
          "name" : "s",
          "value" : "1920x1200"
        }, {
          "name" : "c",
          "value" : "24"
        }, {
          "name" : "j",
          "value" : "1.6"
        }, {
          "name" : "v",
          "value" : "N"
        }, {
          "name" : "k",
          "value" : "Y"
        }, {
          "name" : "bw",
          "value" : "1152"
        }, {
          "name" : "bh",
          "value" : "983"
        }, {
          "name" : "AQE",
          "value" : "1"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 302,
        "statusText" : "Found",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "s_vi",
          "value" : "[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]",
          "path" : "/",
          "domain" : "tiffany.com",
          "expires" : "2019-07-28T13:38:48.000+0000"
        } ],
        "headers" : [ {
          "name" : "Keep-Alive",
          "value" : "timeout=15"
        }, {
          "name" : "Server",
          "value" : "Omniture DC"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Sat, 29 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "P3P",
          "value" : "CP=\"This is not a P3P policy\""
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "X-C",
          "value" : "ms-5.4.0"
        }, {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, max-age=0, no-transform, private"
        }, {
          "name" : "xserver",
          "value" : "www542"
        }, {
          "name" : "Set-Cookie",
          "value" : "s_vi=[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]; Expires=Sun, 28 Jul 2019 13:38:55 GMT; Domain=tiffany.com; Path=/"
        }, {
          "name" : "Expires",
          "value" : "Thu, 27 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "0"
        }, {
          "name" : "Location",
          "value" : "http://stats.tiffany.com/b/ss/tiffanyrus,tiffanyglobal/1/JS-2.1.0-D7QN/s42144444641557?AQB=1&pccr=true&vidn=2CBD9F37851D05F0-40000151C0003403&&ndh=1&pf=1&t=28%2F6%2F2017%2014%3A41%3A40%205%20-60&D=D%3D&fid=635E58A259D7A835-33DAEBDE5968F475&ce=utf-8&pageName=Tiffany%20%26%20Co.%20%7C%20Home&g=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&cc=USD&ch=home&server=www.tiffany.com&c1=Home&h1=Home&h2=us%2CHome&v11=9%3A41%20AM%7CFriday&c12=9%3A41%20AM%7CFriday&c21=desktop&c23=D%3Dg&c24=D%3Dv64&c25=en&c26=Home%20%7C%20Tiffany%20%26%20Co.&c37=D%3Dv49&v41=D%3Dh2&c44=D%3Dv52&v44=D%3Dcc&v52=not%20logged%20in&v64=us%3ATiffany%20%26%20Co.%20%7C%20Home&v65=www.tiffany.com%2Fdefault.aspx&v67=www.tiffany.com&v68=%2B1&c70=high%20resolution&c71=http%3Astats.tiffany.com&c72=epd28&c73=1%3A1%3A1%3A1%3A1%3A1%3A1%3A1%7C2017.07.21%7C2017.07.25%7C2.1.0%7C&c75=D%3Dv65&v83=2017-07-28&s=1920x1200&c=24&j=1.6&v=N&k=Y&bw=1152&bh=983&AQE=1"
        }, {
          "name" : "Content-Type",
          "value" : "text/plain"
        } ],
        "content" : {
          "size" : 0,
          "mimeType" : "text/plain"
        },
        "redirectURL" : "",
        "headersSize" : 16,
        "bodySize" : 0
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 3597,
        "connect" : 129,
        "send" : 0,
        "wait" : 267,
        "receive" : 2,
        "ssl" : -1
      },
      "serverIPAddress" : "63.140.35.172",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:41.379+0000",
      "time" : 1186,
      "request" : {
        "method" : "GET",
        "url" : "http://media.tiffany.com/is/image/Tiffany/2X/20170711_HP_Tile2_3x2Promo_US_love_lock_necklace.jpg?v=20170623131502",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "_uetsid",
          "value" : "_uet58928d15",
          "expires" : "2017-07-28T13:41:40.379+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "_uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "media.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "20170623131502"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Unknown"
        }, {
          "name" : "Cache-Control",
          "value" : "max-age=900"
        }, {
          "name" : "ETag",
          "value" : "\"a83dac2a258f19cbbcd8d975904ae550\""
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 23 Jun 2017 17:17:30 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 13:53:52 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "66805"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:52 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/jpeg"
        } ],
        "content" : {
          "size" : 66805,
          "mimeType" : "image/jpeg"
        },
        "redirectURL" : "",
        "headersSize" : 10,
        "bodySize" : 66805
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 331,
        "connect" : 76,
        "send" : 0,
        "wait" : 162,
        "receive" : 617,
        "ssl" : -1
      },
      "serverIPAddress" : "172.226.70.211",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:41.379+0000",
      "time" : 2301,
      "request" : {
        "method" : "GET",
        "url" : "http://media.tiffany.com/is/image/Tiffany/2X/20170711_HP_Tile1_5x2Promo_US_new_silver_jewelry.jpg?v=20170626101530",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "_uetsid",
          "value" : "_uet58928d15",
          "expires" : "2017-07-28T13:41:40.379+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "_uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "media.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "20170626101530"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Unknown"
        }, {
          "name" : "Cache-Control",
          "value" : "max-age=900"
        }, {
          "name" : "ETag",
          "value" : "\"3b0c56a972ae539a8e5e6fffa50ca774\""
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Mon, 26 Jun 2017 14:16:09 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 13:53:52 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "344685"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:52 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/jpeg"
        } ],
        "content" : {
          "size" : 344685,
          "mimeType" : "image/jpeg"
        },
        "redirectURL" : "",
        "headersSize" : 10,
        "bodySize" : 344685
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 330,
        "connect" : 76,
        "send" : 0,
        "wait" : 164,
        "receive" : 1731,
        "ssl" : -1
      },
      "serverIPAddress" : "172.226.70.211",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:41.380+0000",
      "time" : 970,
      "request" : {
        "method" : "GET",
        "url" : "http://media.tiffany.com/is/image/Tiffany/2X/20170711_HP_Tile3_2x2Promo_US_silver_bracelet_tiffany.jpg?v=20170623131505",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "_uetsid",
          "value" : "_uet58928d15",
          "expires" : "2017-07-28T13:41:40.380+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "_uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "media.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "v",
          "value" : "20170623131505"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Server",
          "value" : "Unknown"
        }, {
          "name" : "Cache-Control",
          "value" : "max-age=900"
        }, {
          "name" : "ETag",
          "value" : "\"cd655065ab9aa64ceba9b88f9081782c\""
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Fri, 23 Jun 2017 17:17:46 GMT"
        }, {
          "name" : "Expires",
          "value" : "Fri, 28 Jul 2017 13:53:52 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "38024"
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:52 GMT"
        }, {
          "name" : "Age",
          "value" : "0"
        }, {
          "name" : "Content-Type",
          "value" : "image/jpeg"
        } ],
        "content" : {
          "size" : 38024,
          "mimeType" : "image/jpeg"
        },
        "redirectURL" : "",
        "headersSize" : 10,
        "bodySize" : 38024
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 329,
        "connect" : 76,
        "send" : 0,
        "wait" : 166,
        "receive" : 399,
        "ssl" : -1
      },
      "serverIPAddress" : "172.226.70.211",
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:45.000+0000",
      "time" : 254,
      "request" : {
        "method" : "GET",
        "url" : "http://stats.tiffany.com/b/ss/tiffanyrus,tiffanyglobal/1/JS-2.1.0-D7QN/s42144444641557?AQB=1&pccr=true&vidn=2CBD9F37851D05F0-40000151C0003403&&ndh=1&pf=1&t=28%2F6%2F2017%2014%3A41%3A40%205%20-60&D=D%3D&fid=635E58A259D7A835-33DAEBDE5968F475&ce=utf-8&pageName=Tiffany%20%26%20Co.%20%7C%20Home&g=http%3A%2F%2Fwww.tiffany.com%2Fdefault.aspx&cc=USD&ch=home&server=www.tiffany.com&c1=Home&h1=Home&h2=us%2CHome&v11=9%3A41%20AM%7CFriday&c12=9%3A41%20AM%7CFriday&c21=desktop&c23=D%3Dg&c24=D%3Dv64&c25=en&c26=Home%20%7C%20Tiffany%20%26%20Co.&c37=D%3Dv49&v41=D%3Dh2&c44=D%3Dv52&v44=D%3Dcc&v52=not%20logged%20in&v64=us%3ATiffany%20%26%20Co.%20%7C%20Home&v65=www.tiffany.com%2Fdefault.aspx&v67=www.tiffany.com&v68=%2B1&c70=high%20resolution&c71=http%3Astats.tiffany.com&c72=epd28&c73=1%3A1%3A1%3A1%3A1%3A1%3A1%3A1%7C2017.07.21%7C2017.07.25%7C2.1.0%7C&c75=D%3Dv65&v83=2017-07-28&s=1920x1200&c=24&j=1.6&v=N&k=Y&bw=1152&bh=983&AQE=1",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "_uetsid",
          "value" : "_uet58928d15",
          "expires" : "2017-07-28T13:41:44.000+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "_uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true; rr_rcs=eF5jYSlN9jA0tDAGAiNdM0sDQ12TtGRT3cQUEyPdZANTczMjU4tky9RkrtyykswUAUMjC0tdQ11DAHe5Dag; s_vi=[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "stats.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ {
          "name" : "AQB",
          "value" : "1"
        }, {
          "name" : "pccr",
          "value" : "true"
        }, {
          "name" : "vidn",
          "value" : "2CBD9F37851D05F0-40000151C0003403"
        }, {
          "name" : "",
          "value" : ""
        }, {
          "name" : "ndh",
          "value" : "1"
        }, {
          "name" : "pf",
          "value" : "1"
        }, {
          "name" : "t",
          "value" : "28/6/2017 14:41:40 5 -60"
        }, {
          "name" : "D",
          "value" : "D"
        }, {
          "name" : "fid",
          "value" : "635E58A259D7A835-33DAEBDE5968F475"
        }, {
          "name" : "ce",
          "value" : "utf-8"
        }, {
          "name" : "pageName",
          "value" : "Tiffany "
        }, {
          "name" : " Co. | Home",
          "value" : ""
        }, {
          "name" : "g",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "cc",
          "value" : "USD"
        }, {
          "name" : "ch",
          "value" : "home"
        }, {
          "name" : "server",
          "value" : "www.tiffany.com"
        }, {
          "name" : "c1",
          "value" : "Home"
        }, {
          "name" : "h1",
          "value" : "Home"
        }, {
          "name" : "h2",
          "value" : "us,Home"
        }, {
          "name" : "v11",
          "value" : "9:41 AM|Friday"
        }, {
          "name" : "c12",
          "value" : "9:41 AM|Friday"
        }, {
          "name" : "c21",
          "value" : "desktop"
        }, {
          "name" : "c25",
          "value" : "en"
        }, {
          "name" : "c26",
          "value" : "Home | Tiffany "
        }, {
          "name" : " Co.",
          "value" : ""
        }, {
          "name" : "v52",
          "value" : "not logged in"
        }, {
          "name" : "v64",
          "value" : "us:Tiffany "
        }, {
          "name" : " Co. | Home",
          "value" : ""
        }, {
          "name" : "v65",
          "value" : "www.tiffany.com/default.aspx"
        }, {
          "name" : "v67",
          "value" : "www.tiffany.com"
        }, {
          "name" : "v68",
          "value" : "+1"
        }, {
          "name" : "c70",
          "value" : "high resolution"
        }, {
          "name" : "c71",
          "value" : "http:stats.tiffany.com"
        }, {
          "name" : "c72",
          "value" : "epd28"
        }, {
          "name" : "c73",
          "value" : "1:1:1:1:1:1:1:1|2017.07.21|2017.07.25|2.1.0|"
        }, {
          "name" : "v83",
          "value" : "2017-07-28"
        }, {
          "name" : "s",
          "value" : "1920x1200"
        }, {
          "name" : "c",
          "value" : "24"
        }, {
          "name" : "j",
          "value" : "1.6"
        }, {
          "name" : "v",
          "value" : "N"
        }, {
          "name" : "k",
          "value" : "Y"
        }, {
          "name" : "bw",
          "value" : "1152"
        }, {
          "name" : "bh",
          "value" : "983"
        }, {
          "name" : "AQE",
          "value" : "1"
        } ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 200,
        "statusText" : "OK",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "s_vi",
          "value" : "[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]",
          "path" : "/",
          "domain" : "tiffany.com",
          "expires" : "2019-07-28T13:38:52.000+0000"
        } ],
        "headers" : [ {
          "name" : "Keep-Alive",
          "value" : "timeout=15"
        }, {
          "name" : "Server",
          "value" : "Omniture DC"
        }, {
          "name" : "Access-Control-Allow-Origin",
          "value" : "*"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Last-Modified",
          "value" : "Sat, 29 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "Pragma",
          "value" : "no-cache"
        }, {
          "name" : "P3P",
          "value" : "CP=\"This is not a P3P policy\""
        }, {
          "name" : "Date",
          "value" : "Fri, 28 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "X-C",
          "value" : "ms-5.4.0"
        }, {
          "name" : "Cache-Control",
          "value" : "no-cache, no-store, max-age=0, no-transform, private"
        }, {
          "name" : "ETag",
          "value" : "\"597B3E6F-D8A5-079BDC9A\""
        }, {
          "name" : "xserver",
          "value" : "www927"
        }, {
          "name" : "Set-Cookie",
          "value" : "s_vi=[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]; Expires=Sun, 28 Jul 2019 13:38:55 GMT; Domain=tiffany.com; Path=/"
        }, {
          "name" : "Vary",
          "value" : "*"
        }, {
          "name" : "Expires",
          "value" : "Thu, 27 Jul 2017 13:38:55 GMT"
        }, {
          "name" : "Content-Length",
          "value" : "43"
        }, {
          "name" : "Content-Type",
          "value" : "image/gif"
        } ],
        "content" : {
          "size" : 43,
          "mimeType" : "image/gif"
        },
        "redirectURL" : "",
        "headersSize" : 17,
        "bodySize" : 43
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 1,
        "wait" : 252,
        "receive" : 1,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:46.502+0000",
      "time" : 59,
      "request" : {
        "method" : "GET",
        "url" : "http://www.tiffany.com/favicon.ico",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ {
          "name" : "dntstatus",
          "value" : "0",
          "expires" : "2017-07-28T13:41:45.502+0000"
        } ],
        "headers" : [ {
          "name" : "Cookie",
          "value" : "dntstatus=0; _uetsid=_uet58928d15; _ga=GA1.2.231298761.1501249300; _gid=GA1.2.1874622682.1501249300; _gat_global=1; _gat_local=1; langprefforca=-1; dtmusersessionid=eb8f612458864fb1a6abbd27f4e5c734; myeid=; samebrowsersession=; assortmentid=101; previoussid=; hascookies1=1; bannercookieinfo={\"CartFilledInCurrentSession\":\"0\",\"IsEntryPageVisited\":\"1\",\"UrlVisit\":\"/default.aspx\"}; taxzpcd=; IsFreshBrowserSession=1; s_fid=635E58A259D7A835-33DAEBDE5968F475; s_gpv_v66=us%3ATiffany%20%26%20Co.%20%7C%20Home; s_gtbe_vis_pur=1501249300991; s_gtbe_vis_pur_ev=1501249300992; s_cc=true; rr_rcs=eF5jYSlN9jA0tDAGAiNdM0sDQ12TtGRT3cQUEyPdZANTczMjU4tky9RkrtyykswUAUMjC0tdQ11DAHe5Dag; s_vi=[CS]v1|2CBD9F37851D05F0-40000151C0003403[CE]; RT=\"sl=1&ss=1501249287426&tt=19039&obo=0&bcn=%2F%2F36eb5555.mpstat.us%2F&sh=1501249306470%3D1%3A0%3A19039&dm=tiffany.com&si=7b15ee6b-b198-4698-9fff-d0fa9def164c&ld=1501249306470\""
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "image/webp,image/apng,image/*,*/*;q=0.8"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "www.tiffany.com"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        } ],
        "queryString" : [ ],
        "headersSize" : 9,
        "bodySize" : -1
      },
      "response" : {
        "status" : 904,
        "statusText" : "Transaction ended",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ ],
        "content" : {
          "size" : 0
        },
        "redirectURL" : "",
        "headersSize" : 0,
        "bodySize" : 0
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : -1,
        "connect" : -1,
        "send" : 0,
        "wait" : 0,
        "receive" : 59,
        "ssl" : -1
      },
      "_wsid" : 0
    }, {
      "pageref" : "1",
      "startedDateTime" : "2017-07-28T13:41:46.503+0000",
      "time" : 348,
      "request" : {
        "method" : "POST",
        "url" : "http://36eb5555.mpstat.us/",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ {
          "name" : "Origin",
          "value" : "http://www.tiffany.com"
        }, {
          "name" : "accountId",
          "value" : "null"
        }, {
          "name" : "Accept",
          "value" : "*/*"
        }, {
          "name" : "User-Agent",
          "value" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4; Neustar WPM) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36"
        }, {
          "name" : "Referer",
          "value" : "http://www.tiffany.com/default.aspx"
        }, {
          "name" : "Connection",
          "value" : "Keep-Alive"
        }, {
          "name" : "Host",
          "value" : "36eb5555.mpstat.us"
        }, {
          "name" : "Accept-Encoding",
          "value" : "gzip, deflate"
        }, {
          "name" : "Accept-Language",
          "value" : "en-GB,en-US;q=0.8,en;q=0.6"
        }, {
          "name" : "Content-Length",
          "value" : "5880"
        }, {
          "name" : "Content-Type",
          "value" : "application/x-www-form-urlencoded"
        } ],
        "queryString" : [ ],
        "postData" : {
          "mimeType" : "application/x-www-form-urlencoded",
          "params" : [ ],
          "text" : ""
        },
        "headersSize" : 11,
        "bodySize" : -1
      },
      "response" : {
        "status" : 904,
        "statusText" : "Transaction ended",
        "httpVersion" : "HTTP/1.1",
        "cookies" : [ ],
        "headers" : [ ],
        "content" : {
          "size" : 0
        },
        "redirectURL" : "",
        "headersSize" : 0,
        "bodySize" : 0
      },
      "cache" : { },
      "timings" : {
        "blocked" : -1,
        "dns" : 348,
        "connect" : -1,
        "send" : 0,
        "wait" : 0,
        "receive" : 0,
        "ssl" : -1
      },
      "serverIPAddress" : "104.16.67.157",
      "_wsid" : 0
    } ],
    "_steps" : [ {
      "step" : 1,
      "label" : "Launch Web Site",
      "startTime" : "2017-07-28T13:41:27.417+0000",
      "duration" : 19100,
      "timePaused" : 0,
      "nameValuePairs" : [ ]
    }, {
      "step" : 2,
      "label" : "Choose your country_ Select United States",
      "startTime" : "2017-07-28T13:41:46.524+0000",
      "duration" : 360,
      "timePaused" : 0,
      "nameValuePairs" : [ ]
    } ],
    "_log" : "begin step: Launch Web Site\r\nbegin step: Choose your country_ Select United States\r\n"
  }
}